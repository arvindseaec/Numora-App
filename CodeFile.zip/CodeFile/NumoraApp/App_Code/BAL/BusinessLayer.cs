﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NumoraApp
{
    public class BusinessLayer
    {
        public List<string> ASCIISort(List<string> lstString)
        {
            lstString = lstString.Where(w => w.ToCharArray().Length > 0)
                .Select(s =>
                new
                {
                    OriginalString = s,
                    GetAsciiofFirstChar = (int)s.ToCharArray().Take(1).Single()
                })
                .OrderBy(o => o.GetAsciiofFirstChar)
                .Select(s => s.OriginalString)
                .Union(lstString.Where(s => s.ToCharArray().Length == 0))
                .ToList();
            return lstString;
        }
    }
    public class Comment
    {
        public string sha { get; set; }
        public Message commit { get; set; }
    }
    public class Message
    {
        public string message { get; set; }
    }
}