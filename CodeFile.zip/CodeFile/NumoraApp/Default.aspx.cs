﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace NumoraApp
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }
        private void bindGridview(string username,string token,string GHERepo)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api.github.com");
                //HTTP GET
                client.DefaultRequestHeaders.UserAgent.Add(new System.Net.Http.Headers.ProductInfoHeaderValue("AppName", "1.0"));
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                string url = string.Format("/repos/{0}/{1}/commits", username, GHERepo);
                var responseTask = client.GetAsync(url);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsAsync<Comment[]>();
                    readTask.Wait();
                    
                    var data = readTask.Result.Where(s => s.sha == token).FirstOrDefault();

                    if (data != null)
                    {
                        btnExport.Visible = true;
                        List<string> arrStr  = data.commit.message.Split(' ').ToList();

                        BusinessLayer obj = new BusinessLayer();                      
                        var arr = obj.ASCIISort(arrStr);
                       
                        Dictionary<string, int> repeatedWordCount = new Dictionary<string, int>();
                        for (int i = 0; i < arr.Count; i++)
                        {
                            if (repeatedWordCount.ContainsKey(arr[i]))
                            {
                                int val = repeatedWordCount[arr[i]];
                                repeatedWordCount[arr[i]] = val + 1;
                            }
                            else
                            {
                                repeatedWordCount.Add(arr[i], 1);
                            }
                        }
                       
                        gvData.DataSource = repeatedWordCount;
                        gvData.DataBind();
                    }
                }
                else
                {
                    lblError.Text = "Invalid UserName/Access Token or GHE Repo";
                    lblError.ForeColor = System.Drawing.Color.Red;
                    return ;
                }
            }
        }
       
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            bindGridview(txtUserName.Text.Trim(), txtAccessToken.Text.Trim(), txtGHERepo.Text.Trim());
        }
        private void ExportGridToCSV()
        {
            bindGridview(txtUserName.Text.Trim(), txtAccessToken.Text.Trim(), txtGHERepo.Text.Trim());
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=test.csv");
            Response.Charset = "";
            Response.ContentType = "application/text";
            gvData.AllowPaging = false;
            gvData.DataBind();
            StringBuilder columnbind = new StringBuilder();
            for (int k = 0; k < gvData.Columns.Count; k++)
            {
                columnbind.Append(gvData.Columns[k].HeaderText + ',');
            }
            columnbind.Append("\r\n");
            for (int i = 0; i < gvData.Rows.Count; i++)
            {
                for (int k = 0; k < gvData.Columns.Count; k++)
                {
                    columnbind.Append(gvData.Rows[i].Cells[k].Text + ',');
                }
                columnbind.Append("\r\n");
            }
            Response.Output.Write(columnbind.ToString());
            Response.Flush();
            Response.End();
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            ExportGridToCSV();
        }
    }
    
}