﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumoraApp;
namespace NumoraTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CheckUsernameIsBlank()
        {
            string username = "";
            Assert.AreEqual(username, string.Empty);
        }
        [TestMethod]
        public void ShortingNumber()
        {
            List<string> arr = new List<string> { "aa", "AA","sas","DD" };
            BusinessLayer obj = new BusinessLayer();
            arr = obj.ASCIISort(arr);
            List<string> actual = new List<string> { "AA", "DD", "aa", "sas" };
            Assert.AreEqual(arr[0], actual[0]);
        }
        
    }
}
